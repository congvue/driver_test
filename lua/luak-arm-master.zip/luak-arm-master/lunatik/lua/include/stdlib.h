#include <linux/kernel.h>

#define exit(E)         return
#define strtoul		simple_strtoul
#define strcoll		strcmp
