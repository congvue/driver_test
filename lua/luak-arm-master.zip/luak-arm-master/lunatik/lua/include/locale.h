struct lconv {
   char * decimal_point ;
} ;

#define localeconv()		NULL
