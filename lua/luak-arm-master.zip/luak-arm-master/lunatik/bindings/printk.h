#ifndef __LUNATIK_BINDINGS_PRINTK
#define __LUNATIK_BINDINGS_PRINTK
#include "../lunatik.h"

int lunatik_printk(lua_State *L);
#endif
