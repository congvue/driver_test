#ifndef __LUNATIK_BINDINGS_GPIO
#define __LUNATIK_BINDINGS_GPIO
#include "../lunatik.h"

int luak_gpio_register(lua_State *L);

#endif
