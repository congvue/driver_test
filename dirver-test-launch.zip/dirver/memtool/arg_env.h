#ifndef _ARG_ENV_
#define _ARG_ENV_

unsigned int hex(char *);

#endif
